"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CreditCard, Lock } from "lucide-react"

interface PaymentFormProps {
  onSubmit: () => void
  isProcessing: boolean
}

export function PaymentForm({ onSubmit, isProcessing }: PaymentFormProps) {
  const [paymentMethod, setPaymentMethod] = useState<"credit-card" | "paypal">("credit-card")
  const [formData, setFormData] = useState({
    cardName: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    country: "",
    postalCode: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    // Format card number with spaces
    if (name === "cardNumber") {
      const formatted = value
        .replace(/\s/g, "")
        .replace(/(\d{4})/g, "$1 ")
        .trim()
      setFormData((prev) => ({ ...prev, [name]: formatted }))
      return
    }

    // Format expiry date with slash
    if (name === "expiryDate") {
      const cleaned = value.replace(/\D/g, "")
      let formatted = cleaned
      if (cleaned.length > 2) {
        formatted = `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`
      }
      setFormData((prev) => ({ ...prev, [name]: formatted }))
      return
    }

    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit()
  }

  return (
    <Card className="bg-gray-800/80 border-none text-white">
      <CardHeader>
        <CardTitle>Payment Details</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex border-b border-gray-700 mb-6">
          <button
            className={`pb-2 px-4 ${
              paymentMethod === "credit-card"
                ? "border-b-2 border-orange-500 text-white"
                : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setPaymentMethod("credit-card")}
          >
            <div className="flex items-center">
              <CreditCard className="mr-2 h-4 w-4" />
              Credit Card
            </div>
          </button>
          <button
            className={`pb-2 px-4 ${
              paymentMethod === "paypal" ? "border-b-2 border-orange-500 text-white" : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setPaymentMethod("paypal")}
          >
            <div className="flex items-center">
              <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a3.35 3.35 0 0 0-.607-.541c-.013.076-.026.175-.041.254-.59 3.025-2.566 4.586-5.611 4.586H13.55c-.524 0-.968.382-1.05.9l-1.143 7.244c-.07.435.211.842.65.842h3.39c.524 0 .968-.382 1.05-.9l.46-2.92.033-.202.717-4.545c.047-.298.29-.533.593-.533h.374c2.39 0 4.526-.45 5.79-1.75.735-.755 1.223-1.702 1.472-2.85l.04-.232c.094-.583.126-1.126.096-1.625a3.52 3.52 0 0 0-.2-.728z" />
              </svg>
              PayPal
            </div>
          </button>
        </div>

        {paymentMethod === "credit-card" ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="cardName">Name on Card</Label>
              <Input
                id="cardName"
                name="cardName"
                placeholder="John Doe"
                value={formData.cardName}
                onChange={handleChange}
                required
                className="bg-white text-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cardNumber">Card Number</Label>
              <div className="relative">
                <Input
                  id="cardNumber"
                  name="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={formData.cardNumber}
                  onChange={handleChange}
                  maxLength={19}
                  required
                  className="bg-white text-black pr-10"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <CreditCard className="h-5 w-5 text-gray-500" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiryDate">Expiry Date</Label>
                <Input
                  id="expiryDate"
                  name="expiryDate"
                  placeholder="MM/YY"
                  value={formData.expiryDate}
                  onChange={handleChange}
                  maxLength={5}
                  required
                  className="bg-white text-black"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cvv">CVV</Label>
                <Input
                  id="cvv"
                  name="cvv"
                  placeholder="123"
                  value={formData.cvv}
                  onChange={handleChange}
                  maxLength={4}
                  required
                  className="bg-white text-black"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, country: value }))}
                >
                  <SelectTrigger className="bg-white text-black">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="au">Australia</SelectItem>
                    <SelectItem value="de">Germany</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="postalCode">Postal Code</Label>
                <Input
                  id="postalCode"
                  name="postalCode"
                  placeholder="12345"
                  value={formData.postalCode}
                  onChange={handleChange}
                  required
                  className="bg-white text-black"
                />
              </div>
            </div>

            <div className="flex items-center text-sm text-gray-400 mt-4">
              <Lock className="h-4 w-4 mr-2 text-gray-500" />
              Your payment information is encrypted and secure.
            </div>

            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3"
              disabled={isProcessing}
            >
              {isProcessing ? "Processing Payment..." : "Complete Payment"}
            </Button>
          </form>
        ) : (
          <div className="text-center py-8">
            <p className="mb-6">You will be redirected to PayPal to complete your payment.</p>
            <Button
              onClick={handleSubmit}
              className="bg-[#0070ba] hover:bg-[#005ea6] text-white py-3 px-6"
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Continue to PayPal"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

