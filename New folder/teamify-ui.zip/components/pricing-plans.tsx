"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckIcon } from "lucide-react"
import Link from "next/link"

// Define the pricing data
const pricingData = {
  monthly: [
    {
      title: "Standard",
      price: "$99",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: [
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
      ],
      buttonText: "Choose Plan",
      buttonVariant: "secondary" as const,
      buttonLink: "/order?plan=standard&billing=monthly",
    },
    {
      title: "Premium",
      price: "$299",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum"],
      buttonText: "Choose Plan",
      buttonVariant: "default" as const,
      buttonLink: "/order?plan=premium&billing=monthly",
      recommended: true,
    },
    {
      title: "Enterprise",
      price: "Custom Plan",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum"],
      buttonText: "Contact Us",
      buttonVariant: "secondary" as const,
      buttonLink: "/contact-us",
    },
  ],
  yearly: [
    {
      title: "Standard",
      price: "$1000",
      period: "Per Year",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: [
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
        "Lorem ipsum",
      ],
      buttonText: "Choose Plan",
      buttonVariant: "secondary" as const,
      buttonLink: "/order?plan=standard&billing=yearly",
    },
    {
      title: "Premium",
      price: "$1800",
      period: "Per Year",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum"],
      buttonText: "Choose Plan",
      buttonVariant: "default" as const,
      buttonLink: "/order?plan=premium&billing=yearly",
      recommended: true,
    },
    {
      title: "Enterprise",
      price: "Custom Plan",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      features: ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum", "Lorem ipsum"],
      buttonText: "Contact Us",
      buttonVariant: "secondary" as const,
      buttonLink: "/contact-us",
    },
  ],
}

export function PricingPlans() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")
  const [plans, setPlans] = useState(pricingData.monthly)

  // Update plans when billing cycle changes
  useEffect(() => {
    setPlans(pricingData[billingCycle])
  }, [billingCycle])

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-2">
          Flexible <span className="text-orange-500">Plans</span>
        </h1>
        <p className="text-xl text-gray-300">Choose a plan that work best for you & your team</p>
      </div>

      {/* Billing Toggle */}
      <div className="flex justify-center mb-12">
        <div className="relative flex items-center p-1 bg-gray-800 rounded-full w-72">
          <button
            onClick={() => setBillingCycle("monthly")}
            className={`relative z-10 py-2 px-6 rounded-full text-sm font-medium transition-colors duration-200 ${
              billingCycle === "monthly" ? "text-black" : "text-white"
            }`}
          >
            Monthly
          </button>

          <button
            onClick={() => setBillingCycle("yearly")}
            className={`relative z-10 py-2 px-6 rounded-full text-sm font-medium transition-colors duration-200 flex items-center ${
              billingCycle === "yearly" ? "text-black" : "text-white"
            }`}
          >
            Yearly
            <span className="ml-1 text-xs bg-orange-500 text-white px-2 py-0.5 rounded-full">Save 60%</span>
          </button>

          {/* Animated Background */}
          <motion.div
            className="absolute inset-0 z-0 h-full rounded-full bg-orange-500"
            initial={false}
            animate={{
              x: billingCycle === "monthly" ? 0 : "50%",
              width: "50%",
            }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            style={{ borderRadius: 9999 }}
          />
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan, index) => (
          <Card
            key={`${plan.title}-${index}`}
            className={`bg-gray-800/80 border-none text-white relative ${plan.recommended ? "md:scale-105 z-10" : ""}`}
          >
            {plan.recommended && (
              <Badge className="absolute top-4 right-4 bg-orange-500 text-white border-none">Recommended</Badge>
            )}
            <CardHeader>
              <CardTitle className="text-xl">{plan.title}</CardTitle>
              <div className="mt-4">
                <span className="text-4xl font-bold">{plan.price}</span>
                {plan.period && <span className="text-sm text-gray-400 ml-1">{plan.period}</span>}
              </div>
              <p className="text-sm text-gray-400 mt-2">{plan.description}</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <CheckIcon className="h-5 w-5 text-orange-500 mr-2 shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant={plan.buttonVariant}
                className={`w-full ${
                  plan.buttonVariant === "default"
                    ? "bg-orange-500 hover:bg-orange-600"
                    : "bg-blue-900 hover:bg-blue-800"
                }`}
                asChild
              >
                <Link href={plan.buttonLink}>{plan.buttonText}</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

