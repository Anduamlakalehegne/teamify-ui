"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Camera } from "lucide-react"

export function CompanySetupForm() {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    companyName: "",
    companyWebsite: "",
    companySize: "0-10",
    industry: "",
    companyEmail: "",
    companyPhone: "",
    address: "",
    logo: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (value: string) => {
    setFormData((prev) => ({ ...prev, companySize: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, industry: value }))
  }

  const handleLogoClick = () => {
    fileInputRef.current?.click()
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        setLogoPreview(result)
        setFormData((prev) => ({ ...prev, logo: result }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate form submission
    setTimeout(() => {
      console.log("Company setup form submitted:", formData)

      // Store company data in localStorage
      localStorage.setItem("companyData", JSON.stringify(formData))

      // Redirect to dashboard or welcome page
      router.push("/welcome")
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="w-full max-w-2xl bg-gray-800/80 text-white border-none">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Set Up Your Company</CardTitle>
        <p className="text-gray-300 mt-2">Complete the information below to set up your virtual office</p>
        <div
          className="mx-auto mt-6 w-28 h-28 rounded-full bg-gray-700 flex items-center justify-center border-2 border-blue-800 relative overflow-hidden cursor-pointer group"
          onClick={handleLogoClick}
        >
          {logoPreview ? (
            <div className="w-full h-full">
              <img src={logoPreview || "/placeholder.svg"} alt="Company logo" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                <Camera className="w-8 h-8 text-white" />
              </div>
            </div>
          ) : (
            <>
              <span className="text-sm text-gray-300 absolute">Company Logo</span>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                <Upload className="w-8 h-8 text-white" />
              </div>
            </>
          )}
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleLogoChange} />
        </div>
        <p className="text-xs text-gray-400 mt-2">Click to upload your company logo</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="companyName" className="text-sm">
                Company Name <span className="text-orange-500">*</span>
              </Label>
              <Input
                id="companyName"
                name="companyName"
                placeholder="Your Company Name"
                value={formData.companyName}
                onChange={handleChange}
                required
                className="bg-white text-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="companyWebsite" className="text-sm">
                Company Website <span className="text-orange-500">*</span>
              </Label>
              <Input
                id="companyWebsite"
                name="companyWebsite"
                placeholder="www.yourcompany.com"
                value={formData.companyWebsite}
                onChange={handleChange}
                required
                className="bg-white text-black"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm">
              Company Size <span className="text-orange-500">*</span>
            </Label>
            <RadioGroup value={formData.companySize} onValueChange={handleRadioChange} className="space-y-2">
              <div className="flex items-center justify-between bg-white text-black px-3 py-2 rounded-sm">
                <Label htmlFor="option-1" className="text-sm font-normal cursor-pointer">
                  0 to 10 Employees
                </Label>
                <RadioGroupItem id="option-1" value="0-10" className="text-orange-500" />
              </div>
              <div className="flex items-center justify-between bg-white text-black px-3 py-2 rounded-sm">
                <Label htmlFor="option-2" className="text-sm font-normal cursor-pointer">
                  11 to 50 Employees
                </Label>
                <RadioGroupItem id="option-2" value="11-50" className="text-orange-500" />
              </div>
              <div className="flex items-center justify-between bg-white text-black px-3 py-2 rounded-sm">
                <Label htmlFor="option-3" className="text-sm font-normal cursor-pointer">
                  &gt; Than 50 Employees
                </Label>
                <RadioGroupItem id="option-3" value="50+" className="text-orange-500" />
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="industry" className="text-sm">
              Industry <span className="text-orange-500">*</span>
            </Label>
            <Select value={formData.industry} onValueChange={handleSelectChange} required>
              <SelectTrigger className="bg-white text-black">
                <SelectValue placeholder="Select your industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="manufacturing">Manufacturing</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="companyEmail" className="text-sm">
                Company Email <span className="text-orange-500">*</span>
              </Label>
              <Input
                id="companyEmail"
                name="companyEmail"
                type="email"
                placeholder="contact@yourcompany.com"
                value={formData.companyEmail}
                onChange={handleChange}
                required
                className="bg-white text-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="companyPhone" className="text-sm">
                Company Phone
              </Label>
              <Input
                id="companyPhone"
                name="companyPhone"
                placeholder="+1 (555) 123-4567"
                value={formData.companyPhone}
                onChange={handleChange}
                className="bg-white text-black"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address" className="text-sm">
              Company Address
            </Label>
            <Input
              id="address"
              name="address"
              placeholder="123 Business St, City, State, ZIP"
              value={formData.address}
              onChange={handleChange}
              className="bg-white text-black"
            />
          </div>

          <div className="pt-4">
            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600 text-white py-6"
              disabled={isLoading}
            >
              {isLoading ? "Setting Up Your Company..." : "Complete Setup"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

