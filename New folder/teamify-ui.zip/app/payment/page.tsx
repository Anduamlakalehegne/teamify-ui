"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { PaymentForm } from "@/components/payment-form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { CheckCircle, ArrowRight } from "lucide-react"

export default function Payment() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState({
    name: "Premium",
    price: "$299",
    period: "per month",
    features: ["All Standard features", "Advanced analytics", "Priority support", "Custom integrations"],
  })

  const handlePaymentSubmit = () => {
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setIsComplete(true)

      // Redirect to success page after a delay
      setTimeout(() => {
        router.push("/welcome")
      }, 3000)
    }, 2000)
  }

  return (
    <main className="min-h-screen flex flex-col relative bg-black text-white">
      <div className="absolute inset-0 z-0">
        <Image src="/images/background.png" alt="Office background" fill className="object-cover opacity-50" priority />
      </div>

      <div className="relative z-10 w-full flex flex-col min-h-screen">
        <Navbar />

        <div className="container mx-auto flex-1 py-12">
          <div className="max-w-4xl mx-auto">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div className={`flex flex-col items-center ${currentStep >= 1 ? "text-orange-500" : "text-gray-500"}`}>
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${currentStep >= 1 ? "border-orange-500 bg-orange-500/20" : "border-gray-500"}`}
                  >
                    {currentStep > 1 ? <CheckCircle className="h-5 w-5" /> : "1"}
                  </div>
                  <span className="text-sm mt-2">Plan Selection</span>
                </div>

                <div className={`flex-1 h-1 mx-2 ${currentStep >= 2 ? "bg-orange-500" : "bg-gray-700"}`}></div>

                <div className={`flex flex-col items-center ${currentStep >= 2 ? "text-orange-500" : "text-gray-500"}`}>
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${currentStep >= 2 ? "border-orange-500 bg-orange-500/20" : "border-gray-500"}`}
                  >
                    {currentStep > 2 ? <CheckCircle className="h-5 w-5" /> : "2"}
                  </div>
                  <span className="text-sm mt-2">Payment Details</span>
                </div>

                <div className={`flex-1 h-1 mx-2 ${currentStep >= 3 ? "bg-orange-500" : "bg-gray-700"}`}></div>

                <div className={`flex flex-col items-center ${currentStep >= 3 ? "text-orange-500" : "text-gray-500"}`}>
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${currentStep >= 3 ? "border-orange-500 bg-orange-500/20" : "border-gray-500"}`}
                  >
                    {currentStep > 3 ? <CheckCircle className="h-5 w-5" /> : "3"}
                  </div>
                  <span className="text-sm mt-2">Confirmation</span>
                </div>
              </div>
            </div>

            {isComplete ? (
              <Card className="bg-gray-800/80 border-none text-white">
                <CardContent className="pt-6 flex flex-col items-center justify-center p-12">
                  <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6">
                    <CheckCircle className="h-10 w-10 text-green-500" />
                  </div>
                  <h2 className="text-3xl font-bold mb-2">Payment Successful!</h2>
                  <p className="text-center text-gray-300 mb-8">
                    Thank you for your purchase. Your subscription has been activated.
                  </p>
                  <p className="text-center text-gray-300 mb-8">You will be redirected to your dashboard shortly...</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  {currentStep === 1 && (
                    <Card className="bg-gray-800/80 border-none text-white">
                      <CardHeader>
                        <CardTitle>Confirm Your Plan</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-gray-700/50 p-4 rounded-lg mb-6">
                          <div className="flex justify-between items-center mb-4">
                            <div>
                              <h3 className="text-xl font-semibold">{selectedPlan.name} Plan</h3>
                              <p className="text-gray-300">Billed monthly</p>
                            </div>
                            <div className="text-right">
                              <span className="text-2xl font-bold">{selectedPlan.price}</span>
                              <span className="text-gray-300 text-sm"> {selectedPlan.period}</span>
                            </div>
                          </div>
                          <Separator className="my-4 bg-gray-600" />
                          <ul className="space-y-2">
                            {selectedPlan.features.map((feature, index) => (
                              <li key={index} className="flex items-start">
                                <CheckCircle className="h-5 w-5 text-orange-500 mr-2 shrink-0 mt-0.5" />
                                <span>{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <button
                          onClick={() => setCurrentStep(2)}
                          className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-md flex items-center justify-center"
                        >
                          Continue to Payment <ArrowRight className="ml-2 h-4 w-4" />
                        </button>
                      </CardContent>
                    </Card>
                  )}

                  {currentStep === 2 && <PaymentForm onSubmit={handlePaymentSubmit} isProcessing={isProcessing} />}
                </div>

                <div>
                  <Card className="bg-gray-800/80 border-none text-white sticky top-8">
                    <CardHeader>
                      <CardTitle>Order Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-300">{selectedPlan.name} Plan</span>
                          <span>{selectedPlan.price}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">Billing Cycle</span>
                          <span>Monthly</span>
                        </div>
                        <Separator className="my-2 bg-gray-600" />
                        <div className="flex justify-between font-semibold">
                          <span>Total</span>
                          <span>{selectedPlan.price}</span>
                        </div>
                      </div>

                      <div className="mt-8">
                        <h4 className="font-medium mb-4">Accepted Payment Methods</h4>
                        <div className="flex flex-wrap gap-3">
                          <img
                            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-1HeceaO6JhHB7pkerbKsjMuv9aKYAF.png"
                            alt="Payment methods"
                            className="h-8"
                          />
                        </div>
                      </div>

                      <div className="mt-8 text-sm text-gray-400">
                        <p>
                          By completing your purchase, you agree to our{" "}
                          <a href="/terms" className="text-orange-500 hover:underline">
                            Terms of Service
                          </a>{" "}
                          and{" "}
                          <a href="/privacy" className="text-orange-500 hover:underline">
                            Privacy Policy
                          </a>
                          .
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>
        </div>

        <Footer />
      </div>
    </main>
  )
}

